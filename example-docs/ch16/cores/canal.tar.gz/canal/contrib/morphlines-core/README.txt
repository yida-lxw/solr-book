Apache Solr Morphlines-Core

*Experimental* - This contrib is currently subject to change in ways that may 
break back compatibility.

This contrib provides a variety of Kite Morphlines features for Solr.